#!/bin/sh

gcloud container clusters create meetup
