docker build -t nginxplusws .
