docker build -t nginxpluslb .
