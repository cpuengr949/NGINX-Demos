docker build -t nginxplus .
