source ../scripts/constants.inc
docker build -t ${dockerPrefix}phpfpmbase .
