<?php print('{"service":"service 2", ' .	
            '"uri":"' . $_SERVER['REQUEST_URI'] . '", ' .  
            '"host":"' . $_SERVER['HTTP_HOST'] .  '", ' . 
            '"ip_address":"' . $_SERVER['SERVER_ADDR'] . '"}')
?>
