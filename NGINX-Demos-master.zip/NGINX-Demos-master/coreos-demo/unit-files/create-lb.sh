#!/bin/bash

fleetctl start loadbalancer@1
fleetctl start loadbalancer-discovery@1
