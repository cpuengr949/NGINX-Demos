#!/bin/bash

[ -z $1 ] || echo parameter;
