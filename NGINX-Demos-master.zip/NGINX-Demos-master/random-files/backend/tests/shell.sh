#!/bin/bash

while ./good.sh ; do

done

