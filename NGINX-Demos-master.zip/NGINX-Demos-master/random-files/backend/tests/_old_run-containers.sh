#!/bin/bash

docker run -p 10.2.2.90:8000:80 -d random-nginx-demo
docker run -p 10.2.2.91:8000:80 -d random-nginx-demo
docker run -p 10.2.2.92:8000:80 -d random-nginx-demo
docker run -p 10.2.2.93:8000:80 -d random-nginx-demo
docker run -p 10.2.2.94:8000:80 -d random-nginx-demo
docker run -p 10.2.2.95:8000:80 -d random-nginx-demo
docker run -p 10.2.2.96:8000:80 -d random-nginx-demo
docker run -p 10.2.2.97:8000:80 -d random-nginx-demo
docker run -p 10.2.2.98:8000:80 -d random-nginx-demo
docker run -p 10.2.2.99:8000:80 -d random-nginx-demo
docker run -p 10.2.2.100:8000:80 -d random-nginx-demo
docker run -p 10.2.2.101:8000:80 -d random-nginx-demo
docker run -p 10.2.2.102:8000:80 -d random-nginx-demo

