#!/bin/bash

docker build -t random-nginx-demo .


