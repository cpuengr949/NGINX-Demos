#ifndef PROJECT_CONF_H_
#define PROJECT_CONF_H_
/*---------------------------------------------------------------------------*/
/* User configuration */
#define MQTT_DEMO_STATUS_LED      LEDS_GREEN
#define MQTT_DEMO_BROKER_IP_ADDR "aaaa::1" // NGINX Plus on tunslip
/*---------------------------------------------------------------------------*/
#endif /* PROJECT_CONF_H_ */
