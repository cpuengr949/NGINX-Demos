#!/bin/bash
docker rm -f $(docker ps -qa)
